Beyond The Wall Android wrapper project
Game HTML: app/src/main/assets/index.html
Launcher image: app/src/main/res/drawable/ic_launcher.png
Build with Gradle 8.7, Android Gradle Plugin 8.6.1, JDK 17, Android SDK 35.
